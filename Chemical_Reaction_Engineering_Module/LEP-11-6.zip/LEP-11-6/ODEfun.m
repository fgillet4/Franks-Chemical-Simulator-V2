function dYfuncvecdV = ODEfun(V,Yfuncvec); 
X = Yfuncvec(1); 
% Explicit equations
Cao=1;
Fao=5;
R = 1.987;
E = 10000;
Ke2 = 75000;
dH = -14000;
T2 = 298;
T1 = 298;
k1 = 0.000035;
To = 480;
T = To-dH*X/(75);
k = k1*exp((E/R)*((1/T1)-(1/T)));
Ke = Ke2*exp((dH/R)*((1/T2)-(1/T)));
ra = -k*Cao*((1-X)-(X/Ke));
Xe = Ke/(1+Ke);
% Differential equations
dXdV = -ra/Fao; 
dYfuncvecdV =[dXdV]; 


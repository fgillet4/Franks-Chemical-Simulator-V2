function dYfuncvecdW = ODEfun(t,Yfuncvec); 
A= Yfuncvec(1);
% Explicit equations
C1= 0.0038746 + 0.2739782*t + 1.574621*t^2 - 0.2550041*t^3;
C2= -33.43818 + 37.18972*t - 11.58838*t^2 + 1.695303*t^3 - 0.1298667*t^4 + 0.005028*t^5 - 7.743*10^-5*t^6;
if t <= 4 && t>=0
    C= C1;
elseif t > 4 && t<=14
     C= C2;
end
dAdt=C;
% Differential equations
dYfuncvecdW=[dAdt];
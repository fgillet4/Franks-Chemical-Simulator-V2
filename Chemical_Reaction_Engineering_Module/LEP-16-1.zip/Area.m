clc
tspan = [0 14]; % Range for the independent variable
y0 = [0]; % Initial values for the dependent variables
[t y]=ode45(@ODEfun,tspan,y0);
z=size(y);
A=y(z(1,1));
X=['Area under the C-curve is ', num2str(A)];
disp(X)


clc
Vspan = [0 5.]; % Range for the independent variable i.e volume of the reactor
y0 = [0]; % Initial values for the dependent variable i.e X
[v,y]=ode45(@ODEfun,Vspan,y0);
z=size(y);
for i=1:z(1,1)
T(i) = 330 + 43.3 * y(i,1); 
Kc(i) = 3.03 * exp(-830.3 * (T(i) - 333) / (T(i) * 333)); 
Xe(i) = Kc(i) / (1 + Kc(i)); % Calculating the values of equilibrium conversion from its expression
end
plot(v,y,v,Xe)
xlabel('V')
ylabel('X')
legend('X','X_e')
title('Adiabatic PFR conversion profiles')
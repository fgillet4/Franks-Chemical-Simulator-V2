function dYfuncvecdV = ODEfun(V,Yfuncvec); 
X = Yfuncvec(1); 
% Explicit equations
Ca0 = 9.3; 
Fa0 = 0.9 * 163; 
T = 330 + 43.3 * X; 
Kc = 3.03 * exp(-830.3 * (T - 333) / (T * 333)); 
k = 31.1 * exp(7906 * (T - 360) / (T * 360)); 
Xe = Kc / (1 + Kc); 
ra = 0 - (k * Ca0 * (1 - ((1 + 1 / Kc) * X))); 
rate = 0 - ra; 
% Differential equation
dXdV = 0 - (ra / Fa0); 
dYfuncvecdV = [dXdV]; 


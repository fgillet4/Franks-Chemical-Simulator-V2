clc
Vspan = [0 5.]; % Range for the independent variable i.e volume of the reactor
y0 = [0]; % Initial values for the dependent variable i.e X
[v,y]=ode45(@ODEfun,Vspan,y0);
z=size(y);
for i=1:z(1,1)
T(i) = 330 + 43.3 * y(i,1); % Calculating the values of T from its expression
end
plot(v,T)
xlabel('V')
ylabel('T')
legend('T')
title('Adiabatic PFR temperature profile')



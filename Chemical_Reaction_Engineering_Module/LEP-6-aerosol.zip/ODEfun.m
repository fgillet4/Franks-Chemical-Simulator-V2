function dYfuncvecdt = ODEfun(t,Yfuncvec); 
T =Yfuncvec(1);
nm=Yfuncvec(2);
N= Yfuncvec(3);
V= Yfuncvec(4);
x= Yfuncvec(5);
% Explicit equations
P = 1.013e5;
Mw = 39.948 / 1000;
R = 8.314;
rhop = 2.7 * 1000;
kB = R / 6.022E23;
m1 = 4.48E-26;
v1 = 1.23E-29;
s1 = 2.575E-19;
Qrt = 2 / (1000 * 60);
Trt = 273;
d = 18 / 1000;
gama = 4.6325e-19;
dg = 0.384e-9;
Q = Qrt * T / Trt;
rhog = P * Mw / (R * T);
meu = (26.69 * sqrt(Mw * 1000 * T) / ((dg * 1.0e+10) ^ 2)) * 1.0E-7;
ps = exp(13.07 - 36373 / T) * P;
lamda = 1 / (sqrt(2) * gama) * kB * T / P;
sigma = (948 - 0.202 * T) / 1000;
nms = ps / (kB * T);
theta = sigma * s1 / (kB * T);
S = nm * rhog / nms;
if S > 1 
rN =((v1 / rhog) * sqrt(2 * sigma / (pi * m1)) * (nms ^ 2) * S * exp(theta - (4 * theta ^ 3 / (27 * log(S) ^ 2))));
else
    rN=0;
end
if S > 1
    nstar= ((2 * theta / (3 * log(S))) ^ 3);
else
    nstar=0;
end
if ((V < 0)|(N < 0)) 
    dp=((6 * v1 / pi) ^ (1 / 3));
else
    dp=((6 * V / ((N + 1) * pi)) ^ (1 / 3) + (6 * v1 / pi) ^ (1 / 3));
end
Kn = 2 * lamda / dp;
fKn = (1.333 * Kn + 1.333 * Kn ^ 2) / (1 + 1.71 * Kn + 1.333 * Kn ^ 2);
vp = pi * dp ^ 3 / 6;
c = sqrt((8 * kB * T) / (pi * rhop * vp));
D = kB * T / (3 * pi * meu * dp) * (5 + 4 * Kn + 6 * Kn ^ 2 + 18 * Kn ^ 3) / (5 - Kn + (8 + pi) * Kn ^ 2);
Ia = 8 * D / (pi * c);
g1 = 1 / (3 * dp * Ia) * ((dp + Ia) ^ 3 - (dp ^ 2 + Ia ^ 2) ^ (3 / 2)) - dp;
beta = 8 * pi * D * dp * ((dp / (dp + sqrt(2) * g1)) + (4 * sqrt(2) * D / (c * dp))) ^ (-1);
if S < 1 
    rC=0;
else
    rC=(nms * (S - 1) * sqrt(kB * T / (2 * pi * m1)) * fKn);
end
rF = beta * N ^ 2 * rhog;

% Differential equations
dTdt = -1000;
dnmdt = -rN * nstar - pi * dp ^ 2 * N * rC;
dNdt = rN - 0.5 * rF;
dVdt = rN * nstar * v1 + pi * (dp ^ 2) * v1 * N * rC;
dxdt = 4 * Q / (pi * d ^ 2) ;
dYfuncvecdt=[dTdt;dnmdt;dNdt;dVdt;dxdt];




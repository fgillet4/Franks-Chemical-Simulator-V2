% Aerosol Reactors Module
% Particle size vs x
clc
tspan = [0 1]; % Range for the time of the reaction 
y0 = [1973;2.634e+022;0;0;0]; % Initial values for the dependent variables i.e. T,nm,N,V,x
[v y]=ode45(@ODEfun,tspan,y0);
q=size(y);
v1 = 1.23E-29;
pi=3.14;
for i=1:q
if ((y(i,4) < 0)|(y(i,3) < 0)) 
    dp(i,1)=((6 * v1 / pi) ^ (1 / 3));
else
    dp(i,1)=((6 * y(i,4) / ((y(i,3) + 1) * pi)) ^ (1 / 3) + (6 * v1 / pi) ^ (1 / 3));
end
end
plot(y(:,5),dp(:,1));
ylabel('dp(m)')
xlabel('x')
legend('dp vs x')





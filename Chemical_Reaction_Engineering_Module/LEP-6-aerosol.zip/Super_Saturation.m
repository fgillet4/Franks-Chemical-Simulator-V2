% Aerosol Reactors Module
% Super Saturation vs x
clc
tspan = [0 1]; % Range for the time of the reaction 
y0 = [1973;2.634e+022;0;0;0]; % Initial values for the dependent variables i.e. T,nm,N,V,x
[v y]=ode45(@ODEfun,tspan,y0);
q=size(y);
P = 1.013e5;
Mw = 39.948 / 1000;
R = 8.314;
kB = R / 6.022E23;
for i=1:q
    ps(i,1) = exp(13.07 - 36373 / y(i,1)) * P;
rhog(i,1) = P * Mw / (R * y(i,1));
nms(i,1) = ps(i,1) / (kB * y(i,1));
S(i,1) = y(i,2) * rhog(i,1) / nms(i,1);
end
plot(y(:,5),S(:,1));
ylabel('Supersaturation ratio')
xlabel('x')
legend('S vs x')





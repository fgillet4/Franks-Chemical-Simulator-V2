% Aerosol Reactors Module
% Monomer concentration vs x
clc
tspan = [0 1]; % Range for the time of the reaction 
y0 = [1973;2.634e+022;0;0;0]; % Initial values for the dependent variables i.e. T,nm,N,V,x
[v y]=ode45(@ODEfun,tspan,y0);
plot(y(:,5),y(:,2));
ylabel('Aluminium Concentration(molecules/kg)')
xlabel('x')





